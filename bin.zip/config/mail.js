module.exports = {
    USER: 'pvanshavali@gmail.com', 
    PASS: 'pvansh2018'
}